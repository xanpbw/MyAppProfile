package com.xan.mvpapp;
//ondate 19/05/2019
//nim: 10116035
//nama:prabowo adi perwira
//kelas:AKB-1(IF-1)
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class SubActivity extends AppCompatActivity {

    EditText nama, nohp;
    TextView notif;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.subactivity);

        nama = (EditText)findViewById(R.id.et_nama);
        nohp = (EditText)findViewById(R.id.et_nohp);
        notif = (TextView)findViewById(R.id.tv_notif);
    }

    public void save(View view){
        nama.setText("");
        nohp.setText("");
        notif.setText("Data Tersimpan");
    }
}

