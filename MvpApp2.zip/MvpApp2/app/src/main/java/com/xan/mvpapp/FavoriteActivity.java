package com.xan.mvpapp;
//ondate 21/05/2019
//nim: 10116035
//nama:prabowo adi perwira
//kelas:AKB-1(IF-1)
import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TabHost;

@SuppressWarnings("deprecation")
public class FavoriteActivity extends TabActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_favorite);

        Intent intent;
        TabHost tabHost = getTabHost();
        TabHost.TabSpec tabSpec;

        intent = new Intent(this, TambahActivity.class);
        tabSpec = getTabHost().newTabSpec("tab1").setIndicator(
                "TAMBAH").setContent(intent);
        tabHost.addTab(tabSpec);

        intent = new Intent(this, TampilkanActivity.class);
        tabSpec = getTabHost().newTabSpec("tab2").setIndicator(
                "TAMPILKAN").setContent(intent);
        tabHost.addTab(tabSpec);
    }
}