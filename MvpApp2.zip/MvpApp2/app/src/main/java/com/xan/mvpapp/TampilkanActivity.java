package com.xan.mvpapp;
//ondate 19/05/2019
//nim: 10116035
//nama:prabowo adi perwira
//kelas:AKB-1(IF-1)
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class TampilkanActivity extends AppCompatActivity {

    EditText nama, nohp;
    TextView notif;
    String nm,nhp;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tampilkan);

        nama = (EditText)findViewById(R.id.et_nama);
        nohp = (EditText)findViewById(R.id.et_nohp);
        notif = (TextView)findViewById(R.id.tv_notif);
    }

    public void save(View view){
        nm=nama.getText().toString().trim();
        nhp=nohp.getText().toString().trim();
        notif.setText(""+nm +"\n"+nhp);
    }
}
